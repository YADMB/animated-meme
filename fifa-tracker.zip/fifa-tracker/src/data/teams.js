export const teamsData = [
  {
    id: 1, name: "USA", group: "A", points: 3, flag: "https://flagcdn.com/w80/us.png",
    players: {
      gk: "Turner",
      df: ["Dest", "Ream", "Richards", "Robinson"],
      mf: ["Adams", "Musah", "Scally"],
      fw: ["Pulisic", "Balogun", "McKennie"]
    }
  },
  {
    id: 2, name: "Mexikó", group: "A", points: 1, flag: "https://flagcdn.com/w80/mx.png",
    players: {
      gk: "Ochoa",
      df: ["Montes", "Vásquez", "Sánchez", "Gallardo"],
      mf: ["Álvarez", "Chávez", "Romo"],
      fw: ["Giménez", "Lozano", "Antuna"]
    }
  },
  {
    id: 3, name: "Kanada", group: "B", points: 0, flag: "https://flagcdn.com/w80/ca.png",
    players: {
      gk: "Crépeau",
      df: ["Johnston", "Miller", "Cornelius", "Davies"],
      mf: ["Eustáquio", "Koné", "Osorio"],
      fw: ["David", "Larin", "Buchanan"]
    }
  },
  {
    id: 4, name: "Magyarország", group: "B", points: 3, flag: "https://flagcdn.com/w80/hu.png",
    players: {
      gk: "Gulácsi",
      df: ["Lang", "Orbán", "Szalai", "Nyilasi"],
      mf: ["Nagy Á.", "Schäfer", "Szoboszlai"],
      fw: ["Sallai", "Varga B.", "Bolla"]
    }
  },
  {
    id: 5, name: "Lengyelország", group: "B", points: 0, flag: "https://flagcdn.com/w80/pl.png",
    players: {
      gk: "Szczęsny",
      df: ["Bednarek", "Dawidowicz", "Kiwior"],
      mf: ["Frankowski", "Zielinski", "Slisz", "Zalewski"],
      fw: ["Lewandowski", "Buksa", "Piątek"]
    }
  },
  {
    id: 6, name: "Anglia", group: "B", points: 0, flag: "https://flagcdn.com/w80/gb-eng.png",
    players: {
      gk: "Pickford",
      df: ["Walker", "Stones", "Guehi", "Trippier"],
      mf: ["Rice", "Bellingham", "Mainoo"],
      fw: ["Saka", "Kane", "Foden"]
    }
  },
  {
    id: 7, name: "Portugália", group: "B", points: 3, flag: "https://flagcdn.com/w80/pt.png",
    players: {
      gk: "Costa",
      df: ["Cancelo", "Dias", "Pepe", "Mendes"],
      mf: ["Fernandes", "Palhinha", "Vitinha"],
      fw: ["Bernardo", "Ronaldo", "Leão"]
    }
  }
];
